import React from "react";
import { InfinityLogo } from "./components/InfinityLogo";
import "./App.css";

function App() {
  return (
    <div className="landing-root">
      <InfinityLogo size={120} />
      <h1 className="brand-title">Virb.io</h1>
    </div>
  );
}

export default App;